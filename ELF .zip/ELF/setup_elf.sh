#!/bin/bash
# ============================================================
# ELF 高通量批量部署脚本 v4
# 用法: bash setup_elf.sh <QE_文件夹路径>
# 目录: ELF/A/B/opt_ELF  +  ELF/A/B/scf_ELF
# ============================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
QE_DIR="$1"
[ -z "$QE_DIR" ] && { echo "Usage: bash setup_elf.sh <QE_folder_path>"; exit 1; }

PBE_LIB="/home/test1/hhy/basic/psudopotential/PAW-GGA-PBE"
ELF_ROOT="./ELF"

find "$QE_DIR" -maxdepth 1 -type d -name "*GPa*" | while read SYSTEM_DIR; do
    BASENAME=$(basename "$SYSTEM_DIR")
    echo "Processing: $BASENAME"

    # --- parse A (name), B (pressure number), C (Tc) ---
    A="${BASENAME%%-*}"
    REST="${BASENAME#$A-}"
    C=$(echo "$REST" | grep -oP '[0-9.]+(?=K$)' | head -1)
    B=$(echo "$REST" | sed "s/-${C}K$//" | grep -oP '[0-9.]+' | head -1)

    if [ -z "$A" ] || [ -z "$B" ] || [ -z "$C" ]; then
        echo "  SKIP: parse fail (A='$A' B='$B' C='$C')"
        continue
    fi
    echo "  A=$A  B=$B  C=$C"

    RELAX_IN=$(find "$SYSTEM_DIR" -maxdepth 3 -name "relax.in" 2>/dev/null | head -1)
    [ -z "$RELAX_IN" ] && { echo "  SKIP: relax.in not found"; continue; }
    echo "  relax.in: $RELAX_IN"

    BASE_DIR="$ELF_ROOT/${A}/${B}"
    OPT_DIR="$BASE_DIR/opt_ELF"
    SCF_DIR="$BASE_DIR/scf_ELF"

    # ============================================================
    # run scripts first (opt=Relaxation, scf=ELF)
    # ============================================================
    python3 - "$BASE_DIR" "$SCRIPT_DIR" << 'PYEOF'
import sys
sys.path.insert(0, sys.argv[2])
from elf_common import setup_run_scripts
opt_dir, scf_dir = setup_run_scripts(sys.argv[1])
print(f"  opt_ELF/ELF.pbs written (Relaxation INCAR)")
print(f"  scf_ELF/ELF.pbs written (ELF INCAR)")
PYEOF
    if [ $? -ne 0 ]; then
        echo "  ERROR: run script setup failed"
        continue
    fi

    # ============================================================
    # POSCAR -> opt_ELF + scf_ELF
    # ============================================================
    python3 - "$RELAX_IN" "$BASE_DIR" "$SCRIPT_DIR" << 'PYEOF'
import sys
sys.path.insert(0, sys.argv[3])
from elf_common import parse_relax_in, deploy_poscar_to_workdirs

relax_in, base_dir = sys.argv[1], sys.argv[2]
structure = parse_relax_in(relax_in)
deploy_poscar_to_workdirs(structure, base_dir)
with open(f"{base_dir}/.elems", "w") as f:
    f.write(" ".join(structure.elements))
summary = " ".join(f"{e}({c})" for e, c in zip(structure.elements, structure.counts))
print(f"  POSCAR: {summary} -> opt_ELF/ + scf_ELF/")
PYEOF
    if [ $? -ne 0 ] || [ ! -f "$OPT_DIR/POSCAR" ] || [ ! -f "$SCF_DIR/POSCAR" ]; then
        echo "  ERROR: POSCAR generation failed"
        continue
    fi
    ELEMENTS=$(cat "$BASE_DIR/.elems")
    rm -f "$BASE_DIR/.elems"

    # ============================================================
    # POTCAR -> opt_ELF + scf_ELF
    # ============================================================
    python3 - "$PBE_LIB" "$BASE_DIR" "$ELEMENTS" "$SCRIPT_DIR" << 'PYEOF'
import sys
sys.path.insert(0, sys.argv[4])
from elf_common import deploy_potcar_to_workdirs

pbe_lib, base_dir, elements_str = sys.argv[1], sys.argv[2], sys.argv[3]
elements = elements_str.split()
sources = deploy_potcar_to_workdirs(elements, base_dir, pbe_lib=pbe_lib)
for elem in elements:
    info = sources[elem]
    print(f"  {elem} -> {info['dir']} (ZVAL={info['zval']}, {info['date']})")
print(f"  POTCAR assembled -> opt_ELF/ + scf_ELF/")
PYEOF
    if [ $? -ne 0 ]; then
        echo "  ERROR: POTCAR assembly failed (POSCAR + ELF.pbs kept)"
        echo "  DONE (partial): $BASE_DIR"
        echo "---------------------------"
        continue
    fi

    echo "  DONE: $BASE_DIR  [opt_ELF + scf_ELF]"
    echo "---------------------------"
done
echo "All done."
