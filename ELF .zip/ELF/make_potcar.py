#!/usr/bin/env python3
"""
make_potcar.py — 按元素顺序拼接 VASP POTCAR

用途:
  从赝势库选取最优单元素 POTCAR，拼接后写入工作目录。
  批量模式下为每个体系的 opt_ELF 与 scf_ELF 各生成一份 POTCAR。

择优规则:
  1. ZVAL（价电子数）最大者优先
  2. ZVAL 相同时，取第一行日期最新者

基本用法:
  python make_potcar.py --poscar ELF/Ag/50/opt_ELF/POSCAR -o ELF/Ag/50/opt_ELF/POTCAR
  python make_potcar.py --scan ./ELF
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import List

from elf_common import (
    DEFAULT_PBE_LIB,
    OPT_SUBDIR,
    SCF_SUBDIR,
    assemble_potcar,
    deploy_potcar_to_workdirs,
    read_poscar_elements,
    setup_run_scripts,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Assemble VASP POTCAR from PBE pseudopotential library."
    )
    parser.add_argument(
        "elements",
        nargs="*",
        help="Element symbols in order (optional if --poscar is given)",
    )
    parser.add_argument(
        "--poscar",
        help="Read element order from POSCAR",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="POTCAR",
        help="Output POTCAR path (default: POTCAR)",
    )
    parser.add_argument(
        "--pbe-lib",
        default=os.environ.get("PBE_LIB", DEFAULT_PBE_LIB),
        help=f"PBE pseudopotential library root (default: {DEFAULT_PBE_LIB})",
    )
    parser.add_argument(
        "--keep-single",
        action="store_true",
        help="Keep per-element <Elem>.POTCAR files in output directory",
    )
    parser.add_argument(
        "--scan",
        metavar="ELF_ROOT",
        help="Batch mode: process opt_ELF + scf_ELF under ELF root",
    )
    return parser


def resolve_elements(args) -> List[str]:
    if args.poscar:
        return read_poscar_elements(args.poscar)
    if args.elements:
        return args.elements
    raise ValueError("Specify elements or use --poscar")


def make_one(
    elements: List[str],
    output: Path,
    pbe_lib: str,
    keep_single: bool = False,
    write_pbs: bool = True,
) -> None:
    sources = assemble_potcar(
        elements,
        output,
        pbe_lib=pbe_lib,
        keep_single=keep_single,
    )
    if write_pbs:
        base = output.parent.parent if output.parent.name in (OPT_SUBDIR, SCF_SUBDIR) else output.parent
        setup_run_scripts(base)

    print(f"POTCAR written: {output}")
    print(f"  rule: max ZVAL, then newest date on line 1")
    for elem, info in sources.items():
        print(f"  {elem} -> {info['dir']} (ZVAL={info['zval']}, {info['date']})")


def make_for_base(
    elements: List[str],
    base_dir: Path,
    pbe_lib: str,
    keep_single: bool,
) -> None:
    setup_run_scripts(base_dir)
    sources = deploy_potcar_to_workdirs(elements, base_dir, pbe_lib=pbe_lib)
    print(f"POTCAR -> {OPT_SUBDIR}/ + {SCF_SUBDIR}/ under {base_dir}")
    for elem, info in sources.items():
        print(f"  {elem} -> {info['dir']} (ZVAL={info['zval']}, {info['date']})")


def batch_scan(elf_root: Path, pbe_lib: str, keep_single: bool) -> int:
    bases = set()
    for sub in (OPT_SUBDIR, SCF_SUBDIR):
        for poscar in sorted(elf_root.rglob(f"{sub}/POSCAR")):
            bases.add(poscar.parent.parent)

    if not bases:
        print(f"No {OPT_SUBDIR}/{SCF_SUBDIR} POSCAR found under {elf_root}")
        return 1

    ok = 0
    for base_dir in sorted(bases):
        opt_poscar = base_dir / OPT_SUBDIR / "POSCAR"
        if not opt_poscar.is_file():
            print(f"SKIP: missing {opt_poscar}")
            continue
        print(f"Processing: {base_dir}")
        try:
            elements = read_poscar_elements(opt_poscar)
            if keep_single:
                for sub in (OPT_SUBDIR, SCF_SUBDIR):
                    make_one(
                        elements,
                        base_dir / sub / "POTCAR",
                        pbe_lib,
                        keep_single=True,
                        write_pbs=False,
                    )
                setup_run_scripts(base_dir)
            else:
                make_for_base(elements, base_dir, pbe_lib, keep_single=False)
            ok += 1
        except (ValueError, FileNotFoundError, OSError) as exc:
            print(f"  ERROR: {exc}")
        print("---------------------------")

    print(f"Finished: {ok}/{len(bases)} systems processed.")
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.scan:
        return batch_scan(Path(args.scan), args.pbe_lib, args.keep_single)

    try:
        elements = resolve_elements(args)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        build_parser().print_help()
        return 1

    output = Path(args.output)
    if output.parent.name in (OPT_SUBDIR, SCF_SUBDIR):
        base_dir = output.parent.parent
        make_for_base(elements, base_dir, args.pbe_lib, args.keep_single)
    else:
        make_one(elements, output, args.pbe_lib, keep_single=args.keep_single)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
